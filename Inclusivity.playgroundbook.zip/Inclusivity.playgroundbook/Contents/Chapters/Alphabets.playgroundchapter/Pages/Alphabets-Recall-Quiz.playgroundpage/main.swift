/*:
 # Alphabets Recall Quiz
 Let's try to recall the hand-poses that you learned on the previous page. Just tap the correct answer choice and get to 5 points to complete this section. There's a tutorial button to help you out in case you get stuck.

 Here's the list of alphabets we're learning today for your reference:

 * **A**: Make a forward-facing fist and keep the thumb next to the index finger
 * **B**: Open your palm but bring the thumb inwards just above the base of the wrist.
 * **I**: Make a fist but raise your little finger while resting your thumb over the index/middle finger.
 * **U**: The peace hand-pose but the index and middle fingers are stuck to each other
 * **V**: The peace hand-pose ✌🏼
 * **Y**: A fist where the thumb and little fingers are raised outwards.

 That's all for this page. Once completed, please proceed to the [next](@next) page.

 */


//#-hidden-code
import PlaygroundSupport
PlaygroundPage.current.liveView = AlphabetQuizWelcomeController()
//#-end-hidden-code

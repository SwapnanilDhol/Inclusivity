/*:
# Alphabet Recognizer using Vision

The system of ASL has well-defined hand-poses for the set of English alphabets. They are presented with a single hand in various poses.


In this section, we'll look at the following alphabets:

* **A**: Make a forward-facing fist and keep the thumb next to the index finger
* **B**: Open your palm but bring the thumb inwards just above the base of the wrist.
* **I**: Make a fist but raise your little finger while resting your thumb over the index/middle finger.
* **U**: The peace hand-pose but the index and middle fingers are stuck to each other
* **V**: The peace hand-pose ✌🏼
* **Y**: A fist where the thumb and little fingers are raised outwards.

 Please make sure the surroundings are well lit, and the iPad can see your hands clearly for accurate detection.

- Note:
 You can also open the tutorial page to view the hand-poses.

*/

/*:
- Important:
  If detection fails, try these out:

    Move your palm towards and away from the camera.\
    Use a different hand.\
    Rotate your hand slightly.\
    In case of still no detection, tap on an answer choice.
*/

/*:
## How does this work?
 The Vision Hand-Pose API (introduced in iOS 14) provides a set of hand landmarks and their points in 2D space. These points are then calculated using mathematical models and formulas (such as Euclidian distance, approximation respecting tolerance, and more) to recognize a gesture. This model is very delicate and is certainly prone to errors but during testing, this system constantly gave more accurate results when compared to a stand-alone ML model, all thanks to the powerful Vision API.


 That's all for this page. Once completed, please proceed to the [next](@next) page.

 */



//#-hidden-code
import PlaygroundSupport
PlaygroundPage.current.liveView = AlphabetHandPoseRecognizerWelcomeController()
//#-end-hidden-code

/*:
 # Phrases Recall Quiz
 Let's try to recall the hand-poses that you learned on the previous page. Just tap the correct answer choice and get to 5 points to complete this section. There's a tutorial button to help you out in case you get stuck.

 Here's the list of phrases that we're learning today for your reference:

 * **Hello**: Open palm facing the subject with the fingers spread away from each other.
 * **I love you**: A fist facing the subject but with the little, index, and thumb raised.
 * **Yes**: An L-shaped gesture between the index finger and the thumb.
 * **Fine**: A thumbs up facing the subject.
 * **Stop**: An open palm where the fingers are close to each other.


That's all for this page. Once completed, please proceed to the [next](@next) page.

 */


//#-hidden-code
import PlaygroundSupport
PlaygroundPage.current.liveView = PhrasesQuizWelcomeController()
//#-end-hidden-code

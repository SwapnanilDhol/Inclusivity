/*:
# Phrases Recognizer using Vision

The system of ASL has well-defined hand-poses for a lot of commonly used phrases. There are multi-hand, action-based, and static hand gestures.

In this section, we'll look at the following phrases:

* **Hello**: Open palm facing the subject with the fingers spread away from each other.
* **I love you**: A fist facing the subject but with the little, index, and thumb raised.
* **Yes**: An L-shaped gesture between the index finger and the thumb.
* **Fine**: A thumbs up facing the subject.
* **Stop**: An open palm where the fingers are close to each other.

 Please make sure the surroundings are well lit, and the iPad can see your hands clearly for accurate detection.

- Note:
 You can also open the tutorial page to view the hand-poses.
 */

/*:
  - Important:
  If detection fails, try these out:


    Move your palm towards and away from the camera.\
    Use a different hand.\
    Rotate your hand slightly.\
    In case of still no detection, tap on an answer choice.
*/

/*:
## How does this work?
 The Vision Hand-Pose API (introduced in iOS 14) provides a set of hand landmarks and their points in 2D space. These points are then calculated using mathematical models and formulas (such as Euclidian distance, approximation respecting tolerance, and more) to recognize a gesture. This model is very delicate and is certainly prone to errors but during testing, this system constantly gave more accurate results when compared to a stand-alone ML model, all thanks to the powerful Vision API.


 That's all for this page. Once completed, please proceed to the [next](@next) page.

 */



//#-hidden-code
import PlaygroundSupport
PlaygroundPage.current.liveView = PhrasesHandPoseRecognizerWelcomeController()
//#-end-hidden-code

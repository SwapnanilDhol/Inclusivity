/*:
 # Inclusivity

According to the United Nations, there are about **10 million people** who have some sort of hearing issues, and over a million have no hearing capability at all just in the United States.

Just like English, Hindi, French, or German, there's a language that consists of various hand-poses that helps us in communicating with people who may not be able to hear us properly or at all. One such language is the ASL or the American Sign language. This system has its roots in the **French sign language system**.

*/

/*:
In this Playground submission, we'll try to become more inclusive by learning a few ASL alphabets and simple phrases that can come in handy the next time we might need it.

 That's all for this page. Once completed, please proceed to the [next](@next) page.

 */

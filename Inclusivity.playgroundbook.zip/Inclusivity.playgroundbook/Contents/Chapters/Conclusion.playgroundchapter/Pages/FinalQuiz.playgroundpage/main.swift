/*:
 # Conclusion

 Good Job! We've successfully learned a few ASL hand-poses for alphabets and commonly used phrases. In this page, we'll conclude what we've learned by playing a simple quiz.

 */

//: # Run the Playground
//: To answer a simple 4 question quiz about what you've just learnt about the ASL system.


//: This is the last page of this Playground submission. Thank you for your time!

/*:

 Acknowledgements and Credits

 * ASL hand-pose images by Coloringbuddymike via Wikimedia commons.
 * Success and Fail sound effects via Freesound.org.
 * Raised button inspired by the work of mohammadghk on Github.

 */


//#-hidden-code
import PlaygroundSupport
PlaygroundPage.current.setLiveView(FinalQuizView())
//#-end-hidden-code

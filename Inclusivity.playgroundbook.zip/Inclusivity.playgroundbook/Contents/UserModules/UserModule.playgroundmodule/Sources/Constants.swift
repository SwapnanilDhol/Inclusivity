/*****************************************************************************
 * Constants.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import Foundation

public struct Constants {

    public struct Score {
        static let visionMax: Int = 10
        static let quizMax: Int = 5
        static let min: Int = 0
    }

    public struct Confidence {
        static let max: Int = 7
        static let min: Int = 0
    }

    public struct AlphabetPromptStrings {

        static let quizMainPrompt = "What is the ASL hand-pose for this alphabet?"
        static let quizWelcomeHeadline = "Alphabet Recall"
        static let quizWelcomeMessage =
            """
            Check if you can recall the ASL hand-poses that you performed for the selected alphabets.

            This quiz contains 5 questions.
            """

        static let visionMainPrompt = "Make the hand-pose for the shown phrase"
        static let visionHelperPrompt = "If detection doesn't work, try out the steps given on the left side of this page."
        static let visionWelcomeHeadline = "Alphabet Hand-Pose Recognization"
        static let visionWelcomeMessage =
            """
            Perform the hand-poses for the alphabets shown on the screen to get to 10 points. This quiz uses the powerful vision framework to classify hand-poses.
            Please tap on the tutorial button and familiarize yourself with the 5 hand-poses.

            This quiz contains 10 questions. Questions are repeated.
            """

        static let visionGameEndMessage =
            """
            You've successfully performed the ASL hand poses for the selected alphabets! In the next Playground page we'll try to recall these hand poses by playing a simple quiz.
            Please proceed to the next page now.

            You may replay the quiz by tapping on the button below.
            """

        static let quizGameEndMessage =
            """
            You've successfully performed and now recalled the ASL hand poses for the selected alphabets! In the next Playground chapter, we'll learn a few phrases in ASL.
            Please proceed to the next page now.

            You may replay the quiz by tapping on the button below.
            """
    }

    public struct PhrasesPromptStrings {

        static let quizMainPrompt = "What is the ASL hand-pose for this phrase?"

        static let quizWelcomeHeadline = "Phrases Recall"
        static let quizWelcomeMessage =
            """
            Check if you can recall the ASL hand-poses that you performed for the selected alphabets.

            This quiz contains 5 questions.
            """
        static let visionMainPrompt = "Make the hand-pose for the shown phrase"
        static let visionHelperPrompt = "If detection doesn't work, try out the steps given on the left side of this page."
        static let visionWelcomeHeadline = "Phrases Hand-Pose Recognization"
        static let visionWelcomeMessage =
            """
            Perform the hand-poses for the phrases shown on the screen to get to 10 points. This quiz uses the powerful vision framework to classify hand-poses.
            Please tap on the tutorial button and familiarize yourself with the 5 hand-poses.

            This quiz contains 10 questions. Questions are repeated
            """

        static let visionGameEndMessage =
            """
            You've successfully performed the ASL hand poses for the selected phrases! In the next Playground page we'll try to recall these hand poses by playing a simple quiz.
            Please proceed to the next page now.

            You may replay the quiz by tapping on the button below.
            """

        static let quizGameEndMessage =
            """
            You've successfully performed and now recalled the ASL hand poses for the selected phrases! In the next Playground chapter, we'll conclude this Playground book by playing a simple quiz to learn more about the ASL system.
            Please proceed to the next page now.

            You may replay the quiz by tapping on the button below.
            """
    }

}

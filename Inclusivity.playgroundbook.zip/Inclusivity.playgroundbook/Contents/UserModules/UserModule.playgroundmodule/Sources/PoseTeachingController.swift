/*****************************************************************************
 * PoseTeachingController.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit

public class PoseTeachingController: UIViewController {

    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "A")
        imageView.layer.cornerRadius = 10
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.heightAnchor.constraint(equalToConstant: 350).isActive = true
        imageView.widthAnchor.constraint(equalToConstant: 350).isActive = true
        return imageView
    }()

    private let headlineLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.textAlignment = .center
        return label
    }()

    private let messageLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 18, weight: .medium)
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()

    private let promptToMoveOnLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 22, weight: .bold)
        label.textAlignment = .center
        label.text = "That's all the poses that we'll learn in this section."
        label.numberOfLines = 0
        return label
    }()

    private let stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    convenience public init(image: UIImage, headlineText: String, messageText: String) {
        self.init(nibName: nil, bundle: nil)
        self.imageView.image = image
        self.headlineLabel.text = headlineText
        self.messageLabel.text = messageText
        setupView()
    }

    //MARK: - Setup

    private func setupView() {
        view.backgroundColor = .systemBackground
        imageView.backgroundColor = .lightGray
        stackView.addArrangedSubview(imageView)
        stackView.addArrangedSubview(headlineLabel)
        stackView.addArrangedSubview(messageLabel)

        if self.headlineLabel.text == "The letter Y" || self.headlineLabel.text == "Stop!" {
            stackView.addArrangedSubview(promptToMoveOnLabel)
            stackView.setCustomSpacing(50, after: messageLabel)
        }

        stackView.setCustomSpacing(20, after: imageView)
        view.addSubview(stackView)
        stackView.centerInSuperview()
    }
}

/*****************************************************************************
 * RaisedButton.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit

enum RaisedButtonColor: String {
    case blue
    case orange
}

public class RaisedButton: UIButton {

    private let blueColor = UIColor(red: 85/255, green: 95/255, blue: 149/255, alpha: 1)
    private let orangeColor = UIColor(red: 244/255, green: 148/255, blue: 115/255, alpha: 1)

    private let blueColorShadow = UIColor(red: 60/255, green: 68/255, blue: 115/255, alpha: 1)
    private let orangeShadowColor = UIColor(red: 209/255, green: 124/255, blue: 82/255, alpha: 1)

    var color: RaisedButtonColor = .orange {
        didSet{
            self.selectColor()
        }
    }

    public override init(frame:CGRect) {
        super.init(frame:frame)
        setup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }

    //MARK: - Setup

    private func setup() {
        layer.cornerRadius = 7
        self.layer.shadowOffset = CGSize(width: 0, height: 6)
        self.layer.shadowOpacity = 1.0
        self.layer.shadowRadius = 0.1 
        self.layer.masksToBounds = false
        self.color = .orange
    }

    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        self.frame.size.height = self.frame.size.height - 4
        self.frame.origin.y = self.frame.origin.y + 4
        switch self.color {
        case .blue:
            self.backgroundColor = blueColorShadow
        case .orange:
            self.backgroundColor = orangeShadowColor
        }
    }

    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesCancelled(touches, with: event)
        UIView.animate(withDuration: 0.2, delay: 0.2, usingSpringWithDamping: 3.0, initialSpringVelocity: 1.0) {
            self.frame.size.height = self.frame.size.height + 4
            self.frame.origin.y = self.frame.origin.y - 4
            switch self.color {
            case .blue:
                self.backgroundColor = self.blueColor
            case .orange:
                self.backgroundColor = self.orangeColor
            }
        }
    }

    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        UIView.animate(withDuration: 0.2, delay: 0.2,
                       usingSpringWithDamping: 3.0,
                       initialSpringVelocity: 1.0) {
            self.frame.size.height = self.frame.size.height + 4
            self.frame.origin.y = self.frame.origin.y - 4

            switch self.color {
            case .blue:
                self.backgroundColor = self.blueColor
            case .orange:
                self.backgroundColor = self.orangeColor
            }
        }
    }

    private func selectColor() {
        switch self.color {
        case .blue :
            self.backgroundColor = blueColor
            self.layer.shadowColor = blueColorShadow.cgColor
            self.setTitleColor(UIColor.white, for: .normal)
        case .orange :
            self.backgroundColor = orangeColor
            self.layer.shadowColor = orangeShadowColor.cgColor
            self.setTitleColor(UIColor.white, for: .normal)
        }
    }
}

/*****************************************************************************
 * HandPoseHelper.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import Vision

public class HandPoseHelper {

    //Shared instance for use as a singleton
    static public let shared = HandPoseHelper()

    public init() { }

    //The thumb has a slightly different set of points than the rest of the fingers

    func createHumanHandPointsForThumb(with points: [VNHumanHandPoseObservation.JointName: VNRecognizedPoint]) -> HumanHandPoseForThumb {
        let tip = points[.thumbTip] ?? VNRecognizedPoint.zero
        let ip = points[.thumbIP] ?? VNRecognizedPoint.zero
        let mp = points[.thumbMP] ?? VNRecognizedPoint.zero
        let cmc = points[.thumbCMC] ?? VNRecognizedPoint.zero

        let humanHandPose = HumanHandPoseForThumb(tip: tip.location,
                                                  ip: ip.location,
                                                  mp: mp.location,
                                                  cmc: cmc.location)
        return humanHandPose
    }

    //For all the points except for the thumb.

    func createHumanHandPointsExceptForThumb(with points: [VNHumanHandPoseObservation.JointName: VNRecognizedPoint],
                                             for jointGroupName: VNHumanHandPoseObservation.JointsGroupName) -> HumanHandPosePointsExceptThumb {
        switch jointGroupName {
        case .indexFinger:
            let tip = points[.indexTip] ?? VNRecognizedPoint.zero
            let dip = points[.indexDIP] ?? VNRecognizedPoint.zero
            let pip = points[.indexPIP] ?? VNRecognizedPoint.zero
            let mcp = points[.indexMCP] ?? VNRecognizedPoint.zero
            let humanHandPose = HumanHandPosePointsExceptThumb(finger: jointGroupName,
                                                               tip: tip.location,
                                                               dip: dip.location,
                                                               pip: pip.location,
                                                               mcp: mcp.location)
            return humanHandPose
        case .middleFinger:
            let tip = points[.middleTip] ?? VNRecognizedPoint.zero
            let dip = points[.middleDIP] ?? VNRecognizedPoint.zero
            let pip = points[.middlePIP] ?? VNRecognizedPoint.zero
            let mcp = points[.middleMCP] ?? VNRecognizedPoint.zero
            let humanHandPose = HumanHandPosePointsExceptThumb(finger: jointGroupName,
                                                               tip: tip.location,
                                                               dip: dip.location,
                                                               pip: pip.location,
                                                               mcp: mcp.location)
            return humanHandPose
        case .ringFinger:
            let tip = points[.ringTip] ?? VNRecognizedPoint.zero
            let dip = points[.ringDIP] ?? VNRecognizedPoint.zero
            let pip = points[.ringPIP] ?? VNRecognizedPoint.zero
            let mcp = points[.ringMCP] ?? VNRecognizedPoint.zero
            let humanHandPose = HumanHandPosePointsExceptThumb(finger: jointGroupName,
                                                               tip: tip.location,
                                                               dip: dip.location,
                                                               pip: pip.location,
                                                               mcp: mcp.location)
            return humanHandPose
        case .littleFinger:
            let tip = points[.littleTip] ?? VNRecognizedPoint.zero
            let dip = points[.littleDIP] ?? VNRecognizedPoint.zero
            let pip = points[.littlePIP] ?? VNRecognizedPoint.zero
            let mcp = points[.littleMCP] ?? VNRecognizedPoint.zero
            let humanHandPose = HumanHandPosePointsExceptThumb(finger: jointGroupName,
                                                               tip: tip.location,
                                                               dip: dip.location,
                                                               pip: pip.location,
                                                               mcp: mcp.location)
            return humanHandPose
        default:
            return HumanHandPosePointsExceptThumb(finger: .thumb,
                                                  tip: .zero,
                                                  dip: .zero,
                                                  pip: .zero,
                                                  mcp: .zero)
        }

    }
}

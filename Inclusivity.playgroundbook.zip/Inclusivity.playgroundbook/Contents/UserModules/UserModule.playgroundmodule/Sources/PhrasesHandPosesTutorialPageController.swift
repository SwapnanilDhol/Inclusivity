/*****************************************************************************
 * PhrasesHandPosesTutorialPageController.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit

public class PhrasesHandPosesTutorialPageController: UIPageViewController {


    private let orderedViewControllers: [UIViewController] = [
        PoseTeachingController(image: "🖐🏼".textToImage(with: .systemFont(ofSize: 400)),
                               headlineText: "Hello",
                               messageText: "Open palm facing the subject with the fingers spread away from each other."),
        PoseTeachingController(image: "🤟🏽".textToImage(with: .systemFont(ofSize: 400)),
                               headlineText: "I love you",
                               messageText: "A fist facing the subject but with the little, index, and thumb raised."),
        PoseTeachingController(image: UIImage(named: "yes")!,
                               headlineText: "Yes!",
                               messageText: "An L shaped gesture between the index finger and the thumb."),
        PoseTeachingController(image:UIImage(named: "fine")!,
                               headlineText: "Fine",
                               messageText: "A thumbs up facing the subject being addressed."),
        PoseTeachingController(image: "✋🏼".textToImage(with: .systemFont(ofSize: 400)),
                               headlineText: "Stop!",
                               messageText: "An open palm but the fingers are close to each other.")]

    override init(transitionStyle style: UIPageViewController.TransitionStyle, navigationOrientation: UIPageViewController.NavigationOrientation, options: [UIPageViewController.OptionsKey : Any]? = nil) {
        super.init(transitionStyle: style, navigationOrientation: navigationOrientation, options: options)
        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setup() {
        view.backgroundColor = .systemBackground
        dataSource = self
        if let firstViewController = orderedViewControllers.first {
            setViewControllers([firstViewController],
                               direction: .forward,
                               animated: true,
                               completion: nil)
        }
    }

    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        for view in self.view.subviews{
            if view is UIPageControl{
                (view as! UIPageControl).currentPageIndicatorTintColor = .label
                (view as! UIPageControl).pageIndicatorTintColor = .lightGray
            }
        }
    }
}

extension PhrasesHandPosesTutorialPageController: UIPageViewControllerDataSource {
    public func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.firstIndex(of: viewController) else {
            return nil
        }

        let previousIndex = viewControllerIndex - 1

        guard previousIndex >= 0 else {
            return nil
        }

        guard orderedViewControllers.count > previousIndex else {
            return nil
        }

        return orderedViewControllers[previousIndex]
    }

    public func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.firstIndex(of: viewController) else {
            return nil
        }

        let nextIndex = viewControllerIndex + 1
        let orderedViewControllersCount = orderedViewControllers.count

        guard orderedViewControllersCount != nextIndex else {
            return nil
        }

        guard orderedViewControllersCount > nextIndex else {
            return nil
        }

        return orderedViewControllers[nextIndex]
    }

    public func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return self.orderedViewControllers.count
    }

    public func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return 0
    }
}

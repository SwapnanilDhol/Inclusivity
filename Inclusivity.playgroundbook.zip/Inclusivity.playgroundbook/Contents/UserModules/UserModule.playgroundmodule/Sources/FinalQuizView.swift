/*****************************************************************************
 * FinalQuizView.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import SwiftUI

public struct FinalQuizView: View {

    private var questions: [String] = [
        "How many people use the ASL?",
        "When was the ASL system introduced?",
        "What does the A in ASL stand for?",
        "The ASL is based off of which other sign-based language family?"]
    private var answers: [[String]] = [
        ["Over a million people", "100k", "200k"],
        ["2020", "2021", "1817"],
        ["American", "Australian", "Atlantic"],
        ["German", "French", "Indian"]
    ]
    private var correctAnswerIndex: [Int] = [0, 2, 0, 1]

    @State private var score: Int = Constants.Score.min
    @State private var isPresenting = false
    @State private var currentQuestion = 0
    private let soundManager = SoundManager.shared

    public init() {}

    public var body: some View {
        VStack() {
            Text("Question: \(self.currentQuestion + 1)")
                .font(.system(size: 18, weight: .medium))
                .multilineTextAlignment(.leading)
                .padding(.top, 40)
            Text(questions[currentQuestion])
                .bold()
                .multilineTextAlignment(.center)
                .font(.system(size: 28))
                .padding(.leading, 25)
                .padding(.trailing, 25)
                .padding(.bottom, 35)

            Spacer()

            Button(action: {
                if self.correctAnswerIndex[self.currentQuestion] == 0 {
                    self.soundManager.playCorrectSound()
                    self.score += 1
                    self.checkIfAllQuestionsDone()
                    self.currentQuestion += 1
                } else {
                    self.soundManager.playIncorrectSound()
                }
            }) {
                ZStack(alignment: .center) {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color(UIColor.systemPink))
                        .shadow(radius: 2)
                    Text(answers[currentQuestion][0])
                        .bold()
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.center)
                        .font(.system(size: 18))
                }

            }
            .frame(width: 320, height: 80)

            Button(action: {
                if self.correctAnswerIndex[self.currentQuestion] == 1 {
                    self.soundManager.playCorrectSound()
                    self.score += 1
                    self.checkIfAllQuestionsDone()
                    self.currentQuestion += 1
                } else {
                    self.soundManager.playIncorrectSound()
                }
            }) {
                ZStack(alignment: .center) {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color(UIColor.systemBlue))
                        .shadow(radius: 2)
                    Text(answers[currentQuestion][1])
                        .foregroundColor(Color.white)
                        .bold()
                        .multilineTextAlignment(.center)
                        .font(.system(size: 18))
                }
            }
            .frame(width: 320, height: 80)

            Button(action: {
                if self.correctAnswerIndex[self.currentQuestion] == 2 {
                    self.soundManager.playCorrectSound()
                    self.score += 1
                    self.checkIfAllQuestionsDone()
                    self.currentQuestion += 1
                } else {
                    self.soundManager.playIncorrectSound()
                }
            }) {
                ZStack(alignment: .center) {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color(UIColor.systemGreen))
                        .shadow(radius: 2)

                    Text(answers[currentQuestion][2])
                        .bold()
                        .multilineTextAlignment(.center)
                        .font(.system(size: 18))
                        .foregroundColor(Color.white)
                        .padding()
                }

            }
            .frame(width: 320, height: 80)

            Spacer()

            Text("Your Score is: \(score)")
                .bold()
                .font(.system(size: 20))
                .padding()
        }
        .sheet(isPresented: $isPresenting) {
            DetailView()
        }
    }

    private func checkIfAllQuestionsDone() {
        if self.currentQuestion == 3 {
            self.isPresenting = true
            self.currentQuestion = 0
            self.score = Constants.Score.min
        }
    }
}

/*****************************************************************************
 * AlphabetHandPosesTutorialPageController.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit

public class AlphabetHandPosesTutorialPageController: UIPageViewController {

    private let orderedViewControllers: [UIViewController] = [
        PoseTeachingController(image: UIImage(named: "A")!, headlineText: "The letter A",
                               messageText: "Make a forward facing fist and keep the thumb next to the index finger"),
        PoseTeachingController(image: UIImage(named: "B")!, headlineText: "The letter B",
                               messageText: "Open your palm but bring the thumb inwards just above the base of the wrist."),
        PoseTeachingController(image: UIImage(named: "I")!, headlineText: "The letter I",
                               messageText: "Make a fist but raise your little finger while resting your thumb over the index/middle finger."),
        PoseTeachingController(image: UIImage(named: "U")!, headlineText: "The letter U",
                               messageText: "The peace hand-pose but the index and middle fingers are stuck to each other"),
        PoseTeachingController(image: UIImage(named: "V")!, headlineText: "The letter V",
                               messageText: "The Peace hand-pose ✌🏼"),
        PoseTeachingController(image: UIImage(named: "Y")!, headlineText: "The letter Y",
                               messageText: "A fist but the thumb and little finger is raised outwards."),
    ]
    
    override public init(transitionStyle style: UIPageViewController.TransitionStyle,
                         navigationOrientation: UIPageViewController.NavigationOrientation,
                         options: [UIPageViewController.OptionsKey : Any]? = nil) {
        super.init(transitionStyle: style,
                   navigationOrientation: navigationOrientation, options: options)
        setup()
    }

    required public init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setup() {
        view.backgroundColor = .systemBackground
        dataSource = self
        if let firstViewController = orderedViewControllers.first {
            setViewControllers([firstViewController],
                               direction: .forward,
                               animated: true,
                               completion: nil)
        }
    }

    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        for view in self.view.subviews{
            if view is UIPageControl{
                (view as! UIPageControl).currentPageIndicatorTintColor = .label
                (view as! UIPageControl).pageIndicatorTintColor = .lightGray
            }
        }
    }
}

extension AlphabetHandPosesTutorialPageController: UIPageViewControllerDataSource {
    public func pageViewController(_ pageViewController: UIPageViewController,
                                   viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.firstIndex(of: viewController) else {
            return nil
        }

        let previousIndex = viewControllerIndex - 1

        guard previousIndex >= 0 else {
            return nil
        }

        guard orderedViewControllers.count > previousIndex else {
            return nil
        }

        return orderedViewControllers[previousIndex]
    }

    public func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.firstIndex(of: viewController) else {
            return nil
        }

        let nextIndex = viewControllerIndex + 1
        let orderedViewControllersCount = orderedViewControllers.count

        guard orderedViewControllersCount != nextIndex else {
            return nil
        }

        guard orderedViewControllersCount > nextIndex else {
            return nil
        }

        return orderedViewControllers[nextIndex]
    }

    public func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return self.orderedViewControllers.count
    }

    public func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return 0
    }
}

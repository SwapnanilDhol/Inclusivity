/*****************************************************************************
 * GameEndController.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit

protocol GameEndDisplayerDelegate: AnyObject {
    func userDidAskForReplay()
}

public class GameEndController: UIViewController {

    weak var displayerDelegate: GameEndDisplayerDelegate?
    private let confettiView = ConfettiView()
    private var gameTimer: Timer?

    private let memojiImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "memoji-party")
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.heightAnchor.constraint(equalToConstant: 250).isActive = true
        imageView.widthAnchor.constraint(equalToConstant: 250).isActive = true
        return imageView
    }()

    private let headlineLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.text = "Congratulations!"
        label.textAlignment = .center
        return label
    }()

    private let messageLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 18, weight: .medium)
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.4
        label.numberOfLines = 0
        return label
    }()

    private let replayButton: UIButton = {
        let button = UIButton()
        button.addTarget(self,
                         action: #selector(dismissButtonDidTap),
                         for: .touchUpInside)
        button.setImage(UIImage(systemName: "gobackward")?.applyingSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 32,
                                                                                                                   weight: .medium))
                        , for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.heightAnchor.constraint(equalToConstant: 60).isActive = true
        button.widthAnchor.constraint(equalToConstant: 60).isActive = true
        button.layer.cornerRadius = 30
        button.tintColor = .white
        button.backgroundColor = .systemTeal
        return button
    }()

    private let imageAndTextStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 5
        stackView.contentMode = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    public convenience init(messageText: String) {
        self.init(nibName: nil, bundle: nil)
        self.messageLabel.text = messageText
        setupView()
    }

    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        showConfetti()
    }

    //MARK: - Setup

    private func setupView() {
        view.backgroundColor = .systemBackground
        imageAndTextStackView.addArrangedSubview(memojiImageView)
        imageAndTextStackView.addArrangedSubview(headlineLabel)
        imageAndTextStackView.addArrangedSubview(messageLabel)
        imageAndTextStackView.addArrangedSubview(replayButton)
        view.addSubview(imageAndTextStackView)



        let guide = view.safeAreaLayoutGuide


        NSLayoutConstraint.activate([
            imageAndTextStackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 25),
            imageAndTextStackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -25),
            imageAndTextStackView.bottomAnchor.constraint(lessThanOrEqualTo: guide.bottomAnchor, constant: -20)
        ])

        imageAndTextStackView.centerInSuperview()
    }

    private func showConfetti() {
        confettiView.frame = view.frame
        view.addSubview(confettiView)
        view.sendSubviewToBack(confettiView)
        confettiView.type = .confetti
        confettiView.colors = [.systemRed, .systemGreen, .systemBlue]
        confettiView.intensity = 2.0
        confettiView.startConfetti()
        gameTimer = Timer.scheduledTimer(timeInterval: 5,
                                         target: self,
                                         selector: #selector(stopConfetti),
                                         userInfo: nil,
                                         repeats: true)
    }

    @objc private func stopConfetti() {
        confettiView.stopConfetti()
        UIView.animate(withDuration: 1.0) {
            self.confettiView.alpha = 0.0
        } completion: {[weak self] complete  in
            guard let self = self else { return }
            self.confettiView.removeFromSuperview()
        }
        gameTimer?.invalidate()
    }


    //MARK: - Button actions

    @objc private func dismissButtonDidTap() {
        displayerDelegate?.userDidAskForReplay()
        self.dismiss(animated: true)
    }
}

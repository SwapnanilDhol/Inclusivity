/*****************************************************************************
 * PhrasesHandPoseRecognizerController.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit
import AVKit
import Vision

public enum VisionRecognizationStatus: String {
    case notDetected = "🤔"
    case detected = "💪🏼"
    case buildingConfidence = "🎉 Building confidence"
}

public enum AvailableGestureHandPoses: String, CaseIterable {
    case hello = "Hello" //🖐🏼
    case loveYou = "I love you" //🤟🏽
    case yes = "Yes" //Image
    case fine = "Fine" //
    case stop = "Stop" //✋🏼
    case none = "None"
}

public class PhrasesHandPoseRecognizerController: UIViewController {

    private let visionRecognizationStatus = VisionRecognizationStatus.self
    private let handPoseHelper = HandPoseHelper.shared
    private let notificationFeedbackGenerator = UINotificationFeedbackGenerator()
    private let impactFeedbackGenerator = UIImpactFeedbackGenerator()
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private var handPoseRequest = VNDetectHumanHandPoseRequest()
    private var currentCharacter = ""
    private var confidence = Constants.Confidence.min
    private var score = Constants.Score.min
    private var labelAnimationDidFinish = false
    private var lastCharacter = ""
    private var currentHandPose: AvailableGestureHandPoses = .fine
    private var letters: [String] = ["Hello", "I love you", "Yes", "Fine", "Stop",
                                     "Hello", "I love you", "Yes", "Fine", "Stop"]
    private let handPoseImages: [String: UIImage]  = ["Hello": "🖐🏼".textToImage(with: .systemFont(ofSize: 250)),
                                                      "I love you": "🤟🏽".textToImage(with: .systemFont(ofSize: 250)),
                                                      "Stop": "✋🏼".textToImage(with: .systemFont(ofSize: 250)),
                                                      "Yes": UIImage(named: "yes")!,
                                                      "Fine": UIImage(named: "fine")!]

    private let captureSession: AVCaptureSession = {
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo
        return captureSession
    }()

    private let questionPromptLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .headline)
        label.text = Constants.PhrasesPromptStrings.visionMainPrompt
        label.textAlignment = .natural
        return label
    }()

    private let helperPromptLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .caption1)
        label.text = Constants.PhrasesPromptStrings.visionHelperPrompt
        label.numberOfLines = 0
        label.textAlignment = .natural
        return label
    }()

    private let currentCharacterLabel: UILabel = {
        let label = UILabel()
        label.font = .rounded(ofSize: 80, weight: .bold)
        label.numberOfLines = 2
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let detectedCharacterLabel: UILabel = {
        let label = UILabel()
        label.font = .rounded(ofSize: 18, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .caption1)
        label.text = "🧐"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let progressView: ProgressView = {
        let progressView = ProgressView()
        progressView.numberOfSteps = 0
        progressView.progressInset = .zero
        progressView.trackColor = .white
        progressView.progressColor = UIColor(red: 241/255, green: 148/255, blue: 115/255, alpha: 1)
        progressView.layer.cornerRadius = 6
        progressView.layer.borderColor = UIColor.label.cgColor
        progressView.layer.borderWidth = 0.8
        progressView.translatesAutoresizingMaskIntoConstraints = false
        return progressView
    }()

    private let firstOptionButton: RaisedButton = {
        let button = RaisedButton()
        button.color = .orange
        button.titleLabel?.font = .rounded(ofSize: 45, weight: .semibold)
        button.imageView?.contentMode = .scaleAspectFit
        button.contentVerticalAlignment = .center
        button.contentHorizontalAlignment = .center
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self,
                         action: #selector(firstOptionButtonDidTap),
                         for: .touchUpInside)
        button.heightAnchor.constraint(equalToConstant: 70).isActive = true
        return button
    }()

    private let secondOptionButton: RaisedButton = {
        let button = RaisedButton()
        button.color = .orange
        button.titleLabel?.font = .rounded(ofSize: 45, weight: .semibold)
        button.imageView?.contentMode = .scaleAspectFit
        button.contentVerticalAlignment = .center
        button.contentHorizontalAlignment = .center
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.addTarget(self,
                         action: #selector(secondOptionButtonDidTap),
                         for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let helpButton: RaisedButton = {
        let button = RaisedButton()
        button.color = .blue
        button.titleLabel?.font = .rounded(ofSize: 20, weight: .medium)
        button.setTitle("Symbols Chart", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self,
                         action: #selector(showASLSheetButtonDidTap),
                         for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.heightAnchor.constraint(equalToConstant: 80).isActive = true
        return button
    }()

    private let topStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.distribution = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let middleStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.backgroundColor = .tertiarySystemGroupedBackground
        stackView.layer.cornerRadius = 10
        stackView.distribution = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let answerChoicesButtonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let helpButtonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 15
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let fullButtonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 15
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    //MARK: - Setup

    private func setupCaptureSession() {
        guard let captureDevice = AVCaptureDevice.default(.builtInWideAngleCamera,
                                                          for: .video,
                                                          position: .front) else { return }
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else { return }
        captureSession.startRunning()
        captureSession.addInput(input)
        setupPreviewLayer()
        setupOutput()
    }

    private func setupPreviewLayer() {
        previewLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
        guard let previewLayer = previewLayer else { return }
        view.layer.addSublayer(previewLayer)
        previewLayer.frame = view.frame
        previewLayer.videoGravity = .resize
        previewLayer.connection?.videoOrientation = .landscapeRight
        previewLayer.opacity = 0.2
    }

    private func setupOutput() {
        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput)
    }

    private func setConstraints() {
        view.backgroundColor = .systemBackground
        progressView.heightAnchor.constraint(equalToConstant: 40).isActive = true
        topStackView.addArrangedSubview(statusLabel)
        topStackView.addArrangedSubview(progressView)
        topStackView.addArrangedSubview(questionPromptLabel)
        topStackView.addArrangedSubview(helperPromptLabel)
        middleStackView.addArrangedSubview(currentCharacterLabel)
        answerChoicesButtonStackView.addArrangedSubview(firstOptionButton)
        answerChoicesButtonStackView.addArrangedSubview(secondOptionButton)
        helpButtonStackView.addArrangedSubview(helpButton)
        fullButtonStackView.addArrangedSubview(answerChoicesButtonStackView)
        fullButtonStackView.addArrangedSubview(helpButtonStackView)
        self.view.addSubview(topStackView)
        self.view.addSubview(middleStackView)
        self.view.addSubview(fullButtonStackView)
        topStackView.setCustomSpacing(10, after: statusLabel)
        topStackView.setCustomSpacing(10, after: progressView)

        let guide = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([

            topStackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 15),
            topStackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -15),
            topStackView.topAnchor.constraint(equalTo: guide.topAnchor, constant: 15),

            progressView.heightAnchor.constraint(equalToConstant: 40),

            fullButtonStackView.bottomAnchor.constraint(equalTo: guide.bottomAnchor, constant: -15),
            fullButtonStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            fullButtonStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
            middleStackView.topAnchor.constraint(equalTo: guide.topAnchor, constant: 200),
            middleStackView.bottomAnchor.constraint(equalTo: fullButtonStackView.topAnchor, constant: -20),
            middleStackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 15),
            middleStackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -15)

        ])

        view.bringSubviewToFront(topStackView)
    }

    //MARK: - View Controller Lifecycle methods

    public override func viewDidLoad() {
        super.viewDidLoad()
        setConstraints()
        setRandomCharacter()
        setupCaptureSession()
    }

    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.frame
        previewLayer?.videoGravity = .resizeAspectFill
    }

    //MARK: - Game Logic

    private func reloadGame() {
        letters = ["Hello", "I love you", "Yes", "Fine", "Stop",
                   "Hello", "I love you", "Yes", "Fine", "Stop"]
        score = Constants.Score.min
        confidence = Constants.Confidence.min
        self.progressView.animateProgress(to: Float(0 / 10.0))
        setRandomCharacter()
        guard !captureSession.isRunning else {
            assertionFailure("The capture session shouldn't be running here")
            return
        }
        captureSession.startRunning()
    }

    private func setRandomCharacter() {
        let randomCharacter = letters.popLast() ?? "Yes"

        guard let newHandPose = AvailableGestureHandPoses(rawValue: randomCharacter) else {
            assertionFailure("Couldn't form random character of type AvailableGestureHandPoses")
            return
        }
        currentHandPose = newHandPose
        setLabel()
    }

    private func setLabel() {
        DispatchQueue.main.async {
            self.currentCharacterLabel.alpha = 0
            self.currentCharacterLabel.text = self.currentHandPose.rawValue
            self.setButtonImages()
            self.animateLabel()
        }
    }

    private func animateLabel() {
        UIView.animate(withDuration: 0.5, delay: 1,
                       usingSpringWithDamping: 0.5, initialSpringVelocity: 5,
                       options: .curveEaseInOut, animations: {
                        self.currentCharacterLabel.alpha = 1.0
                       }) { _ in
            self.labelAnimationDidFinish = true
        }
    }

    private func setButtonImages() {
        var modifiedHandPoseImagesDict = handPoseImages
        modifiedHandPoseImagesDict.removeValue(forKey: currentHandPose.rawValue)
        firstOptionButton.setImage(handPoseImages[currentHandPose.rawValue], for: .normal)
        secondOptionButton.setImage(modifiedHandPoseImagesDict.randomElement()?.value, for: .normal)
    }

    private func startFlowForHandPoseDidDetect() {
        //Reset confidence and Increment score
        self.labelAnimationDidFinish = false
        score += 1
        let doubleCounter = Double(self.score)
        DispatchQueue.main.async {
            self.progressView.animateProgress(to: Float(doubleCounter/10.0))
        }
        self.impactFeedbackGenerator.impactOccurred(intensity: 0.6)
        confidence = Constants.Confidence.min //Reset confidence
        SoundManager.shared.playCorrectSound()

        if score == Constants.Score.visionMax {
            //Player completes game.
            captureSession.stopRunning()
            notificationFeedbackGenerator.notificationOccurred(.success)
            DispatchQueue.main.async {
                self.currentCharacterLabel.text = " "
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                let gameOverController = GameEndController(messageText: Constants.PhrasesPromptStrings.visionGameEndMessage)
                gameOverController.modalPresentationStyle = .fullScreen
                gameOverController.displayerDelegate = self
                self.present(gameOverController, animated: true)
            }
            return
        }
        setRandomCharacter()
    }

    private func angle(between starting: CGPoint, ending: CGPoint) -> CGFloat {
        let center = CGPoint(x: ending.x - starting.x, y: ending.y - starting.y)
        let radians = atan2(center.y, center.x)
        let degrees = radians * 180 / .pi
        return degrees > 0 ? degrees : degrees + degrees
    }

    private func wrongAnswerAlert() {
        SoundManager.shared.playIncorrectSound()
        notificationFeedbackGenerator.notificationOccurred(.error)
        let alertController = UIAlertController(title: "Wrong answer",
                                                message: "That's not the correct match. Please try again",
                                                preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
        present(alertController, animated: true)
    }

    //MARK: - Button action handlers

    @objc private func firstOptionButtonDidTap() {
        startFlowForHandPoseDidDetect()
    }

    @objc private func secondOptionButtonDidTap() {
        wrongAnswerAlert()
    }

    @objc private func showASLSheetButtonDidTap() {
        let controller = PhrasesHandPosesTutorialPageController(transitionStyle: .scroll,
                                                                navigationOrientation: .horizontal)
        controller.presentationController?.delegate = self
        self.present(controller, animated: true) {
            self.captureSession.stopRunning()
        }
    }
}

extension PhrasesHandPoseRecognizerController {

    //MARK: - Vision Hand pose estimation

    private func setupVisionForHandPoseEstimation(with sampleBuffer: CMSampleBuffer) {
        let handler = VNImageRequestHandler(cmSampleBuffer: sampleBuffer, orientation: .left, options: [:])
        do {
            try handler.perform([handPoseRequest])
            guard let observation = handPoseRequest.results?.first else {
                DispatchQueue.main.async { self.statusLabel.text = self.visionRecognizationStatus.notDetected.rawValue }
                return
            }
            // Get points for all fingers
            let thumbPoints = try observation.recognizedPoints(.thumb)
            let wristPoints = try observation.recognizedPoints(.all)
            let indexFingerPoints = try observation.recognizedPoints(.indexFinger)
            let middleFingerPoints = try observation.recognizedPoints(.middleFinger)
            let ringFingerPoints = try observation.recognizedPoints(.ringFinger)
            let littleFingerPoints = try observation.recognizedPoints(.littleFinger)

            let humanThumbPoints = handPoseHelper.createHumanHandPointsForThumb(with: thumbPoints)
            let humanIndexFingerPoints = handPoseHelper.createHumanHandPointsExceptForThumb(with: indexFingerPoints,
                                                                                            for: .indexFinger)
            let humanMiddleFingerPoints = handPoseHelper.createHumanHandPointsExceptForThumb(with: middleFingerPoints,
                                                                                             for: .middleFinger)
            let humanRingFingerPoints = handPoseHelper.createHumanHandPointsExceptForThumb(with: ringFingerPoints,
                                                                                           for: .ringFinger)
            let humanLittleFingerPoints = handPoseHelper.createHumanHandPointsExceptForThumb(with: littleFingerPoints,
                                                                                             for: .littleFinger)

            guard let _ = thumbPoints[.thumbTip],
                  let _ = indexFingerPoints[.indexTip],
                  let _ = ringFingerPoints[.ringTip],
                  let _ = littleFingerPoints[.littleTip] else {
                print("Unable to get tip points.")
                return
            }
            // Ignore low confidence points.
            //            guard thumbTipPoint.confidence > 0.3 &&
            //                    indexTipPoint.confidence > 0.3 else {
            //                print("Not confident enough")
            //                return
            //            }
            DispatchQueue.main.async {
                self.statusLabel.text = self.visionRecognizationStatus.detected.rawValue
            }

            //MARK: - Logic

            switch currentHandPose {
            case .hello:
                let distanceBetweenRingDipWristBase = humanRingFingerPoints.dip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenMiddleDipWristBase = humanMiddleFingerPoints.dip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenIndexDipWristBase = humanIndexFingerPoints.dip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenLittleDipWristBase = humanLittleFingerPoints.dip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let angleBetweenThumbTipIndexMcp = abs(angle(between: humanThumbPoints.tip, ending: humanIndexFingerPoints.mcp))


                if humanIndexFingerPoints.dip.x.isAlmostEqual(to: humanMiddleFingerPoints.dip.x, tolerance: 0.3) &&
                    humanMiddleFingerPoints.dip.x.isAlmostEqual(to: humanRingFingerPoints.dip.x, tolerance: 0.3) &&
                    humanRingFingerPoints.dip.x.isAlmostEqual(to: humanLittleFingerPoints.dip.x, tolerance: 0.3) &&
                    angleBetweenThumbTipIndexMcp < 160 &&
                    distanceBetweenRingDipWristBase > 0.1 &&
                    distanceBetweenMiddleDipWristBase > 0.1 &&
                    distanceBetweenIndexDipWristBase > 0.1 &&
                    distanceBetweenLittleDipWristBase > 0.08
                {
                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = self.visionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = self.visionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }

            case .loveYou:
                let distanceBetweenRingTipWristBase = humanRingFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenMiddleTipWristBase = humanMiddleFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenIndexTipWristBase = humanIndexFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenLittleTipWristBase = humanLittleFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? .zero)

                let xPositionOfIndex = humanIndexFingerPoints.tip.x
                let xPositionOfMiddle = humanMiddleFingerPoints.tip.x
                let xPositionOfLittle = humanLittleFingerPoints.tip.x


                if distanceBetweenRingTipWristBase < distanceBetweenIndexTipWristBase &&
                    distanceBetweenMiddleTipWristBase < distanceBetweenIndexTipWristBase &&
                    distanceBetweenRingTipWristBase < distanceBetweenLittleTipWristBase &&
                    distanceBetweenMiddleTipWristBase < distanceBetweenLittleTipWristBase &&
                    xPositionOfIndex > xPositionOfMiddle &&
                    xPositionOfLittle > xPositionOfMiddle &&
                    humanLittleFingerPoints.tip.x.isAlmostEqual(to: humanIndexFingerPoints.pip.x, tolerance: 0.2) {
                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text =  self.visionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = self.visionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }

            case .yes:
                let distanceThumbTipWrist = humanThumbPoints.tip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceRingDipWrist = humanRingFingerPoints.dip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                //let angleBetweenThumbTipIndexMcp = abs(angle(between: humanThumbPoints.tip, ending: humanIndexFingerPoints.mcp))

                if humanMiddleFingerPoints.dip.x.isAlmostEqual(to: humanRingFingerPoints.dip.x, tolerance: 0.1) &&
                    humanRingFingerPoints.dip.x.isAlmostEqual(to: humanLittleFingerPoints.dip.x, tolerance: 0.1) &&
                    humanIndexFingerPoints.dip.x > humanRingFingerPoints.dip.x &&
                    distanceThumbTipWrist > distanceRingDipWrist {
                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = self.visionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = self.visionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }

            case .fine:
                if humanIndexFingerPoints.pip.y.isAlmostEqual(to: humanMiddleFingerPoints.pip.y, tolerance: 0.1) &&
                    humanMiddleFingerPoints.pip.y.isAlmostEqual(to: humanRingFingerPoints.pip.y, tolerance: 0.1) &&
                    humanRingFingerPoints.pip.y.isAlmostEqual(to: humanLittleFingerPoints.pip.y, tolerance: 0.1) &&
                    humanThumbPoints.tip.y.isAlmostEqual(to: humanIndexFingerPoints.pip.y, tolerance: 0.2) &&
                    humanThumbPoints.tip.distance(to: humanIndexFingerPoints.pip) > 0.075 {
                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = self.visionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = self.visionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }

            case .stop:
                let distanceBetweenRingDipWristBase = humanRingFingerPoints.dip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenMiddleDipWristBase = humanMiddleFingerPoints.dip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenIndexDipWristBase = humanIndexFingerPoints.dip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenLittleDipWristBase = humanLittleFingerPoints.dip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let angleBetweenThumbTipIndexMcp = abs(angle(between: humanThumbPoints.tip, ending: humanIndexFingerPoints.mcp))


                if humanIndexFingerPoints.dip.x.isAlmostEqual(to: humanMiddleFingerPoints.dip.x, tolerance: 0.1) &&
                    humanMiddleFingerPoints.dip.x.isAlmostEqual(to: humanRingFingerPoints.dip.x, tolerance: 0.1) &&
                    humanRingFingerPoints.dip.x.isAlmostEqual(to: humanLittleFingerPoints.dip.x, tolerance: 0.1) &&
                    angleBetweenThumbTipIndexMcp < 160 &&
                    distanceBetweenRingDipWristBase > 0.1 &&
                    distanceBetweenMiddleDipWristBase > 0.1 &&
                    distanceBetweenIndexDipWristBase > 0.1 &&
                    distanceBetweenLittleDipWristBase > 0.08
                {
                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = self.visionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = self.visionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }

            case .none:
                break
            }
        } catch {
            captureSession.stopRunning()
        }
    }
}

extension PhrasesHandPoseRecognizerController: AVCaptureVideoDataOutputSampleBufferDelegate {
    public func captureOutput(_ output: AVCaptureOutput,
                              didOutput sampleBuffer: CMSampleBuffer,
                              from connection: AVCaptureConnection) {
        guard labelAnimationDidFinish else { return }
        setupVisionForHandPoseEstimation(with: sampleBuffer)
    }
}

extension PhrasesHandPoseRecognizerController: GameEndDisplayerDelegate {
    func userDidAskForReplay() {
        reloadGame()
    }
}

extension PhrasesHandPoseRecognizerController: UIAdaptivePresentationControllerDelegate {
    public func presentationControllerDidDismiss(_ presentationController: UIPresentationController) {
        guard !captureSession.isRunning else {
            assertionFailure("\(#file): Capture session was already running")
            return
        }
        captureSession.startRunning()
    }
}

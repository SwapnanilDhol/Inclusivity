/*****************************************************************************
 * PhrasesQuizWelcomeController.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit

final public class PhrasesQuizWelcomeController: UIViewController {

    private let memojiImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "memoji-laptop")
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.heightAnchor.constraint(lessThanOrEqualToConstant: 200).isActive = true
        imageView.widthAnchor.constraint(lessThanOrEqualToConstant: 200).isActive = true
        return imageView
    }()

    private let headlineLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 36, weight: .semibold)
        label.text = Constants.PhrasesPromptStrings.quizWelcomeHeadline
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.8
        label.numberOfLines = 0
        label.textAlignment = .natural
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let messageLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 18, weight: .regular)
        label.textAlignment = .natural
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.text = Constants.PhrasesPromptStrings.quizWelcomeMessage
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let playGameButton: RaisedButton = {
        let button = RaisedButton()
        button.setTitle("Start", for: .normal)
        button.color = .blue
        button.titleLabel?.font = .rounded(ofSize: 28, weight: .semibold)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self,
                         action: #selector(playButtonDidTap),
                         for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.heightAnchor.constraint(equalToConstant: 80).isActive = true
        return button
    }()

    private let handPosesHelperPresentButton: RaisedButton = {
        let button = RaisedButton()
        button.setTitle("Tutorial", for: .normal)
        button.color = .orange
        button.titleLabel?.font = .rounded(ofSize: 28, weight: .semibold)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(tutorialButtonDidTap), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.heightAnchor.constraint(equalToConstant: 80).isActive = true
        return button
    }()

    private let labelStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.distribution = .fillEqually
        stackView.spacing = 5
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let bottomStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    public override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        setup()
    }

    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    //MARK: - Setup

    private func setup() {

        view.backgroundColor = .systemGroupedBackground
        labelStackView.addArrangedSubview(headlineLabel)
        labelStackView.addArrangedSubview(messageLabel)
        stackView.addArrangedSubview(memojiImageView)
        stackView.addArrangedSubview(labelStackView)

        bottomStackView.addArrangedSubview(playGameButton)
        bottomStackView.addArrangedSubview(handPosesHelperPresentButton)

        self.view.addSubview(stackView)
        self.view.addSubview(bottomStackView)

        //stackView.setCustomSpacing(20, after: playGameButton)

        let guide = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([
            bottomStackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 25),
            bottomStackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -25),
            bottomStackView.bottomAnchor.constraint(equalTo: guide.bottomAnchor, constant: -20),

            stackView.topAnchor.constraint(lessThanOrEqualTo: guide.topAnchor, constant: 30),
            stackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 25),
            stackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -25),
            stackView.bottomAnchor.constraint(lessThanOrEqualTo: bottomStackView.topAnchor, constant: -15)
        ])

    }

    //MARK: - Button actions

    @objc private func playButtonDidTap() {
        let controller = PhrasesQuizController(nibName: nil, bundle: nil)
        controller.modalPresentationStyle = .fullScreen
        self.present(controller, animated: true)
    }

    @objc private func tutorialButtonDidTap() {
        let controller = PhrasesHandPosesTutorialPageController(transitionStyle: .scroll,
                                                         navigationOrientation: .horizontal)
        self.present(controller, animated: true)
    }
}

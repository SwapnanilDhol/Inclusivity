/*****************************************************************************
 * PhrasesQuizController.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit

public class PhrasesQuizController: UIViewController {

    private var labelAnimationDidFinish = false
    private var firstOptionIsTheCorrectAnswerChoice = true
    private var score = Constants.Score.min
    private var currentHandPose: String = ""
    private var lastCharacter: String = ""
    private let notificationFeedbackGenerator = UINotificationFeedbackGenerator()
    private let impactFeedbackGenerator = UIImpactFeedbackGenerator()
    private var letters: [String] = [ "Hello", "I love you", "Yes", "Stop",
        "Hello", "I love you", "Yes", "Stop", "Fine"
    ]
    private let handPoseImages: [String: UIImage]  = [
        "Hello": "🖐🏼".textToImage(with: .systemFont(ofSize: 250)),
        "I love you": "🤟🏽".textToImage(with: .systemFont(ofSize: 250)),
        "Stop": "✋🏼".textToImage(with: .systemFont(ofSize: 250)),
        "Yes": UIImage(named: "yes")!,
        "Fine": UIImage(named: "fine")!
    ]

    private let dismissButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(systemName: "xmark.circle",
                                withConfiguration: UIImage.SymbolConfiguration(font: .systemFont(ofSize: 24,
                                                                                                 weight: .bold))),
                        for: .normal)
        button.tintColor = .systemRed
        button.addTarget(self, action: #selector(dismissButtonDidTap), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let questionPromptLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .headline)
        label.text = Constants.PhrasesPromptStrings.quizMainPrompt
        label.numberOfLines = 2
        label.textAlignment = .natural
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let currentHandPoseImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    private let progressView: ProgressView = {
        let progressView = ProgressView()
        progressView.numberOfSteps = 0
        progressView.progressInset = .zero
        progressView.trackColor = .white
        progressView.progressColor = UIColor(red: 241/255, green: 148/255, blue: 115/255, alpha: 1)
        progressView.layer.cornerRadius = 6
        progressView.layer.borderColor = UIColor.label.cgColor
        progressView.layer.borderWidth = 0.8
        progressView.translatesAutoresizingMaskIntoConstraints = false
        return progressView
    }()

    private let firstOptionButton: RaisedButton = {
        let button = RaisedButton()
        button.color = .orange
        button.titleLabel?.font = .systemFont(ofSize: 22, weight: .semibold)
        button.imageView?.contentMode = .scaleAspectFit
        button.contentVerticalAlignment = .center
        button.contentHorizontalAlignment = .center
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self,
                         action: #selector(firstOptionButtonDidTap),
                         for: .touchUpInside)
        button.heightAnchor.constraint(equalToConstant: 100).isActive = true
        return button
    }()

    private let secondOptionButton: RaisedButton = {
        let button = RaisedButton()
        button.color = .orange
        button.titleLabel?.font = .systemFont(ofSize: 22, weight: .semibold)
        button.imageView?.contentMode = .scaleAspectFit
        button.contentVerticalAlignment = .center
        button.contentHorizontalAlignment = .center
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.addTarget(self,
                         action: #selector(secondOptionDidTap),
                         for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.4
        return button
    }()

    private let helpButton: RaisedButton = {
        let button = RaisedButton()
        button.color = .blue
        button.titleLabel?.font = .systemFont(ofSize: 22, weight: .medium)
        button.setTitle("Symbols Chart", for: .normal)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.4
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self,
                         action: #selector(showASLSheetButtonDidTap),
                         for: .touchUpInside)
        button.heightAnchor.constraint(equalToConstant: 80).isActive = true
        return button
    }()

    private let topStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 5
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let middleStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.backgroundColor = .systemGroupedBackground
        stackView.layer.cornerRadius = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let answerChoicesButtonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let helpButtonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 15
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let fullButtonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 15
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    override public init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        setup()
    }

    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    //MARK: - Setup

    private func setup() {
        view.backgroundColor = .systemGroupedBackground
        progressView.heightAnchor.constraint(equalToConstant: 40).isActive = true

        topStackView.addArrangedSubview(progressView)
        topStackView.addArrangedSubview(questionPromptLabel)

        middleStackView.addArrangedSubview(currentHandPoseImageView)
        answerChoicesButtonStackView.addArrangedSubview(firstOptionButton)
        answerChoicesButtonStackView.addArrangedSubview(secondOptionButton)
        helpButtonStackView.addArrangedSubview(helpButton)
        fullButtonStackView.addArrangedSubview(answerChoicesButtonStackView)
        fullButtonStackView.addArrangedSubview(helpButtonStackView)

        self.view.addSubview(dismissButton)
        self.view.addSubview(topStackView)
        self.view.addSubview(middleStackView)
        self.view.addSubview(fullButtonStackView)

        let guide = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([

            dismissButton.topAnchor.constraint(equalTo: guide.topAnchor, constant: 15),
            dismissButton.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 15),

            topStackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 15),
            topStackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -15),
            topStackView.topAnchor.constraint(equalTo: dismissButton.bottomAnchor, constant: 15),

            progressView.heightAnchor.constraint(equalToConstant: 40),

            fullButtonStackView.bottomAnchor.constraint(equalTo: guide.bottomAnchor, constant: -15),
            fullButtonStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            fullButtonStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),

            middleStackView.topAnchor.constraint(equalTo: questionPromptLabel.bottomAnchor, constant: 20),
            middleStackView.bottomAnchor.constraint(equalTo: fullButtonStackView.topAnchor, constant: -20),
            middleStackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 15),
            middleStackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -15),

        ])

        view.bringSubviewToFront(topStackView)
    }

    private func setButtonTitles() {
        let randomNumber = arc4random_uniform(200)
        let randomElement = letters.randomElement()!
        if randomElement == currentHandPose {
            setButtonTitles()
            return
        }

        if randomNumber.isMultiple(of: 2) {
            firstOptionIsTheCorrectAnswerChoice = true
            firstOptionButton.setTitle(currentHandPose, for: .normal)
            secondOptionButton.setTitle(randomElement, for: .normal)
        } else {
            firstOptionIsTheCorrectAnswerChoice = false
            secondOptionButton.setTitle(currentHandPose, for: .normal)
            firstOptionButton.setTitle(randomElement, for: .normal)
        }
    }

    private func setLabel() {
        DispatchQueue.main.async {
            self.currentHandPoseImageView.alpha = 0
            self.currentHandPoseImageView.image = self.handPoseImages[self.currentHandPose]
            self.setButtonTitles()
            self.animateLabel()
        }
    }

    private func animateLabel() {
        UIView.animate(withDuration: 0.5, delay: 0.5,
                       usingSpringWithDamping: 0.5, initialSpringVelocity: 5,
                       options: .curveEaseInOut, animations: {
                        self.currentHandPoseImageView.alpha = 1.0
                       }) { _ in
            self.labelAnimationDidFinish = true
        }
    }

    //MARK: - View Controller lifecycle

    override public func viewDidLoad() {
        super.viewDidLoad()
        setRandomCharacter()
        setMiddleStackViewBackgroundColor()
    }

    public override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        setMiddleStackViewBackgroundColor()
    }

    private func setMiddleStackViewBackgroundColor() {
        let currentTrait = traitCollection.userInterfaceStyle
        if currentTrait == .dark {
            middleStackView.backgroundColor = UIColor.white.withAlphaComponent(0.7)
        } else {
            middleStackView.backgroundColor = .systemGroupedBackground
        }
    }

    //MARK: - Game Logic

    private func setRandomCharacter() {
        guard let randomCharacter = letters.last else {
            assertionFailure("Couldn't get random character")
            return
        }

        if lastCharacter == randomCharacter {
            setRandomCharacter()
        } else {
            lastCharacter = randomCharacter
            letters.removeLast(1)
        }

        //Removing element from array

        guard let newHandPose = AvailableGestureHandPoses(rawValue: randomCharacter) else {
            assertionFailure("Couldn't form random character")
            return
        }
        currentHandPose = newHandPose.rawValue
        setLabel()
    }

    private func correctOptionDidTap() {
        SoundManager.shared.playCorrectSound()
        self.labelAnimationDidFinish = false
        score += 1
        let doubleCounter = Double(self.score)
        self.progressView.animateProgress(to: Float(doubleCounter/5.0))
        self.impactFeedbackGenerator.impactOccurred(intensity: 0.6)
        self.currentHandPoseImageView.image = UIImage()

        if score == Constants.Score.quizMax {
            notificationFeedbackGenerator.notificationOccurred(.success)
            DispatchQueue.main.async {
                let gameOverController = GameEndController(messageText: Constants.PhrasesPromptStrings.quizGameEndMessage)
                gameOverController.modalPresentationStyle = .fullScreen
                gameOverController.displayerDelegate = self
                self.present(gameOverController, animated: true)
            }
            return
        }
        setRandomCharacter()
    }

    private func reloadGame() {
        letters = ["Hello", "I love you", "Yes", "Fine", "Stop",
                   "Hello", "I love you", "Yes", "Fine", "Stop"]
        score = Constants.Score.min
        self.progressView.animateProgress(to: Float(0/5.0))
        setRandomCharacter()
    }

    private func wrongAnswerAlert() {
        SoundManager.shared.playIncorrectSound()
        notificationFeedbackGenerator.notificationOccurred(.error)
        let alertController = UIAlertController(title: "Wrong answer",
                                                message: "That's not the correct match. Please try again",
                                                preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
        present(alertController, animated: true)
    }

    //MARK: - Button Action Handlers

    @objc private func firstOptionButtonDidTap() {

        guard labelAnimationDidFinish else { return }

        if firstOptionIsTheCorrectAnswerChoice {
            correctOptionDidTap()
        } else {
            wrongAnswerAlert()
        }
    }

    @objc private func secondOptionDidTap() {

        guard labelAnimationDidFinish else { return }

        if !firstOptionIsTheCorrectAnswerChoice {
            correctOptionDidTap()
        } else {
            wrongAnswerAlert()
        }
    }

    @objc private func showASLSheetButtonDidTap() {
        let controller = PhrasesHandPosesTutorialPageController(transitionStyle: .scroll,
                                                                navigationOrientation: .horizontal)
        self.present(controller, animated: true)
    }

    @objc private func dismissButtonDidTap() {

        let alertController = UIAlertController(title: "Are you sure?",
                                                message: "Dismissing this view will lose all the progress",
                                                preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: .destructive, handler: { _ in
            self.dismiss(animated: true)
        }))
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alertController, animated: true)
    }
}

extension PhrasesQuizController: GameEndDisplayerDelegate {
    func userDidAskForReplay() {
        reloadGame()
    }
}

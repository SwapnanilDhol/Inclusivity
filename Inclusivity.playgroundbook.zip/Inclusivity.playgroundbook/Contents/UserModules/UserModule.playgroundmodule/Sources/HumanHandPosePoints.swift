/*****************************************************************************
 * HumanHandPosePoints.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import Vision

struct HumanHandPosePointsExceptThumb {
    let finger: VNHumanHandPoseObservation.JointsGroupName
    let tip, dip, pip, mcp: CGPoint
}

struct HumanHandPoseForThumb {
    let finger: VNHumanHandPoseObservation.JointsGroupName = .thumb
    let tip, ip, mp, cmc: CGPoint
}

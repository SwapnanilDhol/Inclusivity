/*****************************************************************************
 * DetailView.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import SwiftUI

public struct DetailView: View {

    @State private var pulsate = false

    public init() { }

    public var body: some View {
        VStack {
            Image(systemName: "heart.fill")
                .font(.system(size: 250))
                .foregroundColor(Color.red)
                .scaleEffect(pulsate ? 0.5 : 0.8)
                .animation(Animation.easeInOut(duration: 1).delay(0).repeatCount(20,
                                                                                 autoreverses: true))
                .onAppear() {
                    self.pulsate.toggle()
                }
            Text("Thank you for viewing my playground.")
                .multilineTextAlignment(.center)
                .font(.system(size: 30, weight: .bold))
                .padding(.bottom, 10)
            Text("I hope you've learnt a few ASL hand-poses for alphabets and commonly used phrases that can make your conversations more inclusive.")
                .fontWeight(.medium)
                .multilineTextAlignment(.center)
                .padding(.top, 10)
                .padding(.bottom, 10)
            Text("Together we move forward and build a better tomorrow!")
                .bold()
                .multilineTextAlignment(.center)
                .padding(.top, 10)
                .padding(.bottom, 10)
           Text("If you'd like to take this quiz again, simply dismiss this view by swiping down")
            .font(.footnote)
            .multilineTextAlignment(.center)
            .padding()
        }.padding()
    }
}

/*****************************************************************************
 * SoundButton.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit
import AVKit

public class SoundManager {

    private let audioFiles = ["successSound.mp3", "failSound.wav"]
    private var player: AVAudioPlayer?
    static let shared = SoundManager()

    public init() {
        self.player?.prepareToPlay()
    }

    func playCorrectSound() {

        guard let path = Bundle.main.path(forResource: audioFiles[0], ofType:nil) else { return }
        let url = URL(fileURLWithPath: path)
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }

    func playIncorrectSound() {
        guard let path = Bundle.main.path(forResource: audioFiles[1], ofType:nil) else { return }
        let url = URL(fileURLWithPath: path)
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
}

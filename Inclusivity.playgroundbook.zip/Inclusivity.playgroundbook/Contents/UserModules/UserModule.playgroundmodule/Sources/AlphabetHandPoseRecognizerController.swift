/*****************************************************************************
 * AvailableAlphabetHandPoses.swift
 * Inclusivity. SSC 2021
 *****************************************************************************
 * Copyright (c) 2021 Swapnanil Dhol. All rights reserved.
 *
 * Authors: Swapnanil Dhol <swapnanildhol # gmail.com>
 *
 *****************************************************************************/

import UIKit
import AVKit
import Vision

enum AvailableAlphabetHandPoses: String, CaseIterable {
    case a = "A"
    case b = "B"
    case i = "I"
    case u = "U"
    case v = "V"
    case y = "Y"
    case none = "none"
}

public class AlphabetHandPoseRecognizerController: UIViewController {

    private var previewLayer: AVCaptureVideoPreviewLayer?
    private let handPoseHelper = HandPoseHelper.shared
    private let notificationFeedbackGenerator = UINotificationFeedbackGenerator()
    private let impactFeedbackGenerator = UIImpactFeedbackGenerator()
    private var handPoseRequest = VNDetectHumanHandPoseRequest()
    private var letters: [String] = ["A", "B", "U", "V", "A", "B", "Y", "U", "V", "Y", "A", "B"]
    private var confidence = Constants.Confidence.min
    private var score = Constants.Score.min
    private var currentHandPose: AvailableAlphabetHandPoses = .none
    private var labelAnimationDidFinish = false
    private var currentCharacter = ""
    private var lastCharacter = ""
    private let handPoseImages: [String: UIImage]  = ["A": UIImage(named: "A")!,
                                                      "B": UIImage(named: "B")!,
                                                      "I": UIImage(named: "I")!,
                                                      "U": UIImage(named: "U")!,
                                                      "V": UIImage(named: "V")!,
                                                      "Y": UIImage(named: "Y")!]

    private let captureSession: AVCaptureSession = {
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo
        return captureSession
    }()

    private let questionPromptLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .headline)
        label.text = Constants.PhrasesPromptStrings.visionMainPrompt
        label.textAlignment = .natural
        return label
    }()

    private let helperPromptLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .caption1)
        label.text = Constants.PhrasesPromptStrings.visionHelperPrompt
        label.numberOfLines = 0
        label.textAlignment = .natural
        return label
    }()

    private let currentCharacterLabel: UILabel = {
        let label = UILabel()
        label.font = .rounded(ofSize: 200, weight: .bold)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let detectedCharacterLabel: UILabel = {
        let label = UILabel()
        label.font = .rounded(ofSize: 18, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .caption1)
        label.text = "🧐"
        return label
    }()

    private let progressView: ProgressView = {
        let progressView = ProgressView()
        progressView.numberOfSteps = 0
        progressView.progressInset = .zero
        progressView.trackColor = .white
        progressView.progressColor = UIColor(red: 241/255, green: 148/255, blue: 115/255, alpha: 1)
        progressView.layer.cornerRadius = 6
        progressView.layer.borderColor = UIColor.label.cgColor
        progressView.layer.borderWidth = 0.8
        return progressView
    }()

    private let firstOptionButton: RaisedButton = {
        let button = RaisedButton()
        button.imageView?.contentMode = .scaleAspectFit
        button.contentVerticalAlignment = .center
        button.contentHorizontalAlignment = .center
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.color = .orange
        button.titleLabel?.font = .rounded(ofSize: 45, weight: .semibold)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(firstOptionButtonDidTap), for: .touchUpInside)
        button.heightAnchor.constraint(equalToConstant: 100).isActive = true
        return button
    }()

    private let secondOptionButton: RaisedButton = {
        let button = RaisedButton()
        button.imageView?.contentMode = .scaleAspectFit
        button.contentVerticalAlignment = .center
        button.contentHorizontalAlignment = .center
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.color = .orange
        button.titleLabel?.font = .rounded(ofSize: 45, weight: .semibold)
        button.addTarget(self, action: #selector(secondOptionButtonDidTap), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let helpButton: RaisedButton = {
        let button = RaisedButton()
        button.setTitle("Hand-Poses Help", for: .normal)
        button.color = .blue
        button.titleLabel?.font = .rounded(ofSize: 20, weight: .medium)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(showASLSheetButtonDidTap), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.heightAnchor.constraint(equalToConstant: 100).isActive = true
        return button
    }()

    private let topStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.distribution = .equalSpacing
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let middleStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.backgroundColor = .tertiarySystemGroupedBackground
        stackView.layer.cornerRadius = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let answerChoicesButtonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let helpButtonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 15
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let fullButtonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 15
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    //MARK: - View Controller lifecycle methods

    public override func viewDidLoad() {
        super.viewDidLoad()
        setConstraints()
        setRandomCharacter()
        setupCaptureSession()
    }

    //MARK: - Setup

    private func setConstraints() {
        view.backgroundColor = .systemBackground
        progressView.heightAnchor.constraint(equalToConstant: 40).isActive = true
        topStackView.addArrangedSubview(statusLabel)
        topStackView.addArrangedSubview(progressView)
        topStackView.addArrangedSubview(questionPromptLabel)
        topStackView.addArrangedSubview(helperPromptLabel)
        middleStackView.addArrangedSubview(currentCharacterLabel)
        answerChoicesButtonStackView.addArrangedSubview(firstOptionButton)
        answerChoicesButtonStackView.addArrangedSubview(secondOptionButton)
        helpButtonStackView.addArrangedSubview(helpButton)
        fullButtonStackView.addArrangedSubview(answerChoicesButtonStackView)
        fullButtonStackView.addArrangedSubview(helpButtonStackView)
        self.view.addSubview(topStackView)
        self.view.addSubview(middleStackView)
        self.view.addSubview(fullButtonStackView)
        topStackView.setCustomSpacing(10, after: statusLabel)
        topStackView.setCustomSpacing(10, after: progressView)

        let guide = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([

            topStackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 15),
            topStackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -15),
            topStackView.topAnchor.constraint(equalTo: guide.topAnchor, constant: 15),

            progressView.heightAnchor.constraint(equalToConstant: 40),

            fullButtonStackView.bottomAnchor.constraint(equalTo: guide.bottomAnchor, constant: -15),
            fullButtonStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            fullButtonStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),

            middleStackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 15),
            middleStackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -15),
            middleStackView.topAnchor.constraint(equalTo: guide.topAnchor, constant: 120),
            middleStackView.bottomAnchor.constraint(equalTo: fullButtonStackView.topAnchor, constant: -10)
        ])

        view.bringSubviewToFront(topStackView)
    }

    private func setupCaptureSession() {
        guard let captureDevice = AVCaptureDevice.default(.builtInWideAngleCamera,
                                                          for: .video,
                                                          position: .front) else { return }
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else { return }
        captureDevice.set(frameRate: 5)
        captureSession.startRunning()
        captureSession.addInput(input)
        setupPreviewLayer()
        setupOutput()
    }

    private func setupPreviewLayer() {
        previewLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
        guard let previewLayer = previewLayer else { return }
        view.layer.addSublayer(previewLayer)
        previewLayer.frame = view.frame
        previewLayer.videoGravity = .resizeAspectFill
        previewLayer.connection?.videoOrientation = .landscapeRight
        previewLayer.opacity = 0.2
    }

    private func setupOutput() {
        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput)
    }

    //MARK: - Reload game logic

    private func reloadGame() {
        letters = ["A", "B", "U", "V", "A", "B", "I", "U", "V", "Y", "Y", "A", "B"].reversed()
        score = Constants.Score.min
        confidence = Constants.Confidence.min
        self.progressView.animateProgress(to: Float(0/10.0))
        setRandomCharacter()
        guard !captureSession.isRunning else {
            assertionFailure("The capture session shouldn't be running here")
            return
        }
        captureSession.startRunning()
    }

    //MARK: - Game Logic

    private func setRandomCharacter() {
        let randomCharacter = letters.last ?? "A"

        if lastCharacter == randomCharacter {
            setRandomCharacter()
        } else {
            lastCharacter = randomCharacter
            letters.removeLast(1)
        }

        //Removing element from array

        guard let newHandPose = AvailableAlphabetHandPoses(rawValue: randomCharacter) else {
            assertionFailure("Couldn't form random character")
            return
        }
        currentHandPose = newHandPose
        setLabel()
    }

    private func setLabel() {
        DispatchQueue.main.async {
            self.currentCharacterLabel.alpha = 0
            self.currentCharacterLabel.text = self.currentHandPose.rawValue
            self.setButtonImages()
            self.animateLabel()
        }
    }

    private func animateLabel() {
        UIView.animate(withDuration: 0.5, delay: 1,
                       usingSpringWithDamping: 0.5, initialSpringVelocity: 5,
                       options: .curveEaseInOut, animations: {
                        self.currentCharacterLabel.alpha = 1.0
                       }) { _ in
            self.labelAnimationDidFinish = true
        }
    }

    private func setButtonImages() {
        var modifiedHandPoseImagesDict = handPoseImages
        modifiedHandPoseImagesDict.removeValue(forKey: currentHandPose.rawValue)
        firstOptionButton.setImage(handPoseImages[currentHandPose.rawValue], for: .normal)
        secondOptionButton.setImage(modifiedHandPoseImagesDict.randomElement()?.value, for: .normal)
    }

    private func startFlowForHandPoseDidDetect() {
        //Reset confidence and Increment score
        SoundManager.shared.playCorrectSound()
        self.labelAnimationDidFinish = false
        self.score += 1

        let doubleCounter = Double(self.score)
        DispatchQueue.main.async {
            self.progressView.animateProgress(to: Float(doubleCounter/10.0))
        }
        self.impactFeedbackGenerator.impactOccurred(intensity: 0.6)
        confidence = Constants.Confidence.min

        if score == Constants.Score.visionMax {
            //Player completes game.
            captureSession.stopRunning()
            notificationFeedbackGenerator.notificationOccurred(.success)
            DispatchQueue.main.async {
                self.currentCharacterLabel.text = ""
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                let gameOverController = GameEndController(messageText: Constants.AlphabetPromptStrings.visionGameEndMessage)
                gameOverController.modalPresentationStyle = .fullScreen
                gameOverController.displayerDelegate = self
                self.present(gameOverController, animated: true)
            }
            return
        }
        setRandomCharacter()
    }

    private func wrongAnswerAlert() {
        SoundManager.shared.playIncorrectSound()
        notificationFeedbackGenerator.notificationOccurred(.error)
        let alertController = UIAlertController(title: "Wrong answer",
                                                message: "That's not the correct match. Please try again",
                                                preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
        present(alertController, animated: true)
    }

    //MARK: - Button action handlers

    @objc private func firstOptionButtonDidTap() {
        startFlowForHandPoseDidDetect()
    }

    @objc private func secondOptionButtonDidTap() {
        wrongAnswerAlert()
    }

    @objc private func showASLSheetButtonDidTap() {
        let controller = AlphabetHandPosesTutorialPageController(transitionStyle: .scroll,
                                                                 navigationOrientation: .horizontal)
        controller.presentationController?.delegate = self
        self.present(controller, animated: true) {
            self.captureSession.stopRunning()
        }
    }


    //MARK: - Vision Hand pose estimation

    private func setupVisionForHandPoseEstimation(with sampleBuffer: CMSampleBuffer) {
        let handler = VNImageRequestHandler(cmSampleBuffer: sampleBuffer,
                                            orientation: currentHandPose == .i ? .up : .left, //Hack to get I working
                                            options: [:])
        do {
            try handler.perform([handPoseRequest])
            guard let observation = handPoseRequest.results?.first else {
                DispatchQueue.main.async {
                    self.statusLabel.text = VisionRecognizationStatus.notDetected.rawValue
                }
                return
            }
            // Get points for all fingers
            let thumbPoints = try observation.recognizedPoints(.thumb)
            let wristPoints = try observation.recognizedPoints(.all)
            let indexFingerPoints = try observation.recognizedPoints(.indexFinger)
            let middleFingerPoints = try observation.recognizedPoints(.middleFinger)
            let ringFingerPoints = try observation.recognizedPoints(.ringFinger)
            let littleFingerPoints = try observation.recognizedPoints(.littleFinger)

            let humanThumbPoints = handPoseHelper.createHumanHandPointsForThumb(with: thumbPoints)
            let humanIndexFingerPoints = handPoseHelper.createHumanHandPointsExceptForThumb(with: indexFingerPoints,
                                                                                            for: .indexFinger)
            let humanMiddleFingerPoints = handPoseHelper.createHumanHandPointsExceptForThumb(with: middleFingerPoints,
                                                                                             for: .middleFinger)
            let humanRingFingerPoints = handPoseHelper.createHumanHandPointsExceptForThumb(with: ringFingerPoints,
                                                                                           for: .ringFinger)
            let humanLittleFingerPoints = handPoseHelper.createHumanHandPointsExceptForThumb(with: littleFingerPoints,
                                                                                             for: .littleFinger)


            guard let thumbTipPoint = thumbPoints[.thumbTip],
                  let indexTipPoint = indexFingerPoints[.indexTip],
                  let _ = ringFingerPoints[.ringTip],
                  let _ = littleFingerPoints[.littleTip] else {
                print("Unable to get tip points.")
                return
            }
            // Ignore low confidence points.
//            guard thumbTipPoint.confidence > 0.3 &&
//                    indexTipPoint.confidence > 0.3 else {
//                print("Not confident enough")
//                return
//            }

            DispatchQueue.main.async {
                self.statusLabel.text = VisionRecognizationStatus.detected.rawValue
            }

            //MARK: - Logic

            switch currentHandPose {
            case .a:
                if humanIndexFingerPoints.pip.x.isAlmostEqual(to: humanMiddleFingerPoints.pip.x, tolerance: 0.1) &&
                    humanRingFingerPoints.pip.x.isAlmostEqual(to: humanLittleFingerPoints.pip.x, tolerance: 0.1) &&
                    humanIndexFingerPoints.pip.x.isAlmostEqual(to: humanThumbPoints.ip.x, tolerance: 0.15) &&
                    humanIndexFingerPoints.tip.x.isAlmostEqual(to: wristPoints[.wrist]?.location.x ?? 0.0, tolerance: 0.2) {
                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = VisionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = VisionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }
            case .b:

                let distanceBetweenWristBaseAndThumbTip = humanThumbPoints.tip.distance(to: wristPoints[.wrist]?.location ?? .zero)
                let distanceBetweenWristBaseAndMiddleTip = humanIndexFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? .zero)

                if humanIndexFingerPoints.mcp.x.isAlmostEqual(to: humanMiddleFingerPoints.mcp.x, tolerance: 0.05) &&
                    humanMiddleFingerPoints.mcp.x.isAlmostEqual(to: humanRingFingerPoints.mcp.x, tolerance: 0.05) &&
                    humanRingFingerPoints.mcp.x.isAlmostEqual(to: humanLittleFingerPoints.mcp.x, tolerance: 0.05) &&
                    humanThumbPoints.ip.y.isAlmostEqual(to: humanMiddleFingerPoints.dip.y, tolerance: 0.2) &&
                    distanceBetweenWristBaseAndThumbTip < distanceBetweenWristBaseAndMiddleTip {
                    if self.confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = VisionRecognizationStatus.buildingConfidence.rawValue
                        }
                        self.confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = VisionRecognizationStatus.detected.rawValue
                    }
                    self.confidence = Constants.Confidence.min
                }
            case .i:
                if humanIndexFingerPoints.pip.x.isAlmostEqual(to: humanMiddleFingerPoints.pip.x, tolerance: 0.2) &&
                    humanIndexFingerPoints.pip.x.isAlmostEqual(to: humanThumbPoints.ip.x, tolerance: 0.2) &&
                    humanIndexFingerPoints.tip.x.isAlmostEqual(to: wristPoints[.wrist]?.location.x ?? 0.0, tolerance: 0.3) &&
                    humanLittleFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? CGPoint.zero) > humanIndexFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? CGPoint.zero) {

                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = VisionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = VisionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }

            case .u:
                let differenceInDistanceBetweenIndexTipAndWristBase = humanIndexFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? CGPoint.zero) - humanRingFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? CGPoint.zero)
                if (humanIndexFingerPoints.pip.x.isAlmostEqual(to: humanMiddleFingerPoints.pip.x, tolerance: 0.1)) &&
                    differenceInDistanceBetweenIndexTipAndWristBase > 0.25 &&
                    (humanThumbPoints.tip.y.isAlmostEqual(to: humanRingFingerPoints.dip.y, tolerance: 0.1)) {
                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = VisionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = VisionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }
            case .v:
                let differenceInDistanceBetweenIndexTipAndWristBase = humanIndexFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? CGPoint.zero) - humanRingFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? CGPoint.zero)
                if (humanIndexFingerPoints.pip.x.isAlmostEqual(to: humanMiddleFingerPoints.pip.x, tolerance: 0.3)) &&
                    differenceInDistanceBetweenIndexTipAndWristBase > 0.25 &&
                    (humanThumbPoints.tip.y.isAlmostEqual(to: humanRingFingerPoints.dip.y, tolerance: 0.1)) {
                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = VisionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = VisionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }

            case .y:
                let distanceBetweenThumbTipAndLittleTip = humanThumbPoints.tip.distance(to: humanLittleFingerPoints.tip)
                let distanceBetweenLittleTipAndWristBase = humanLittleFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? CGPoint.zero)
                let distanceBetweenMiddleTipAndWristBase = humanMiddleFingerPoints.tip.distance(to: wristPoints[.wrist]?.location ?? CGPoint.zero)

                if humanIndexFingerPoints.dip.x.isAlmostEqual(to: humanMiddleFingerPoints.dip.x, tolerance: 0.1) &&
                    humanMiddleFingerPoints.dip.x.isAlmostEqual(to: humanRingFingerPoints.dip.x, tolerance: 0.1) &&
                    distanceBetweenThumbTipAndLittleTip > 0.25 &&
                    distanceBetweenLittleTipAndWristBase > distanceBetweenMiddleTipAndWristBase {
                    if confidence == Constants.Confidence.max {
                        self.labelAnimationDidFinish = false
                        self.startFlowForHandPoseDidDetect()
                    } else {
                        DispatchQueue.main.async {
                            self.statusLabel.text = VisionRecognizationStatus.buildingConfidence.rawValue
                        }
                        confidence += 1
                    }
                } else {
                    DispatchQueue.main.async {
                        self.statusLabel.text = VisionRecognizationStatus.detected.rawValue
                    }
                    confidence = Constants.Confidence.min
                }
            case .none:
                break
            }
        } catch {
            captureSession.stopRunning()
        }
    }
}

extension AlphabetHandPoseRecognizerController: AVCaptureVideoDataOutputSampleBufferDelegate {
    public func captureOutput(_ output: AVCaptureOutput,
                              didOutput sampleBuffer: CMSampleBuffer,
                              from connection: AVCaptureConnection) {
        guard labelAnimationDidFinish else { return }
        setupVisionForHandPoseEstimation(with: sampleBuffer)
    }
}

extension AlphabetHandPoseRecognizerController: GameEndDisplayerDelegate {
    func userDidAskForReplay() {
        reloadGame()
    }
}

extension AlphabetHandPoseRecognizerController: UIAdaptivePresentationControllerDelegate {
    public func presentationControllerDidDismiss(_ presentationController: UIPresentationController) {
        guard !captureSession.isRunning else {
            assertionFailure("\(#file): Capture session was already running")
            return
        }
        captureSession.startRunning()
    }
}
